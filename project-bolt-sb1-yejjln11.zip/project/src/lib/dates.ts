const ARABIC_DAYS = [
  'الأحد',
  'الإثنين',
  'الثلاثاء',
  'الأربعاء',
  'الخميس',
  'الجمعة',
  'السبت',
];

const ARABIC_MONTHS_GREG = [
  'يناير',
  'فبراير',
  'مارس',
  'أبريل',
  'مايو',
  'يونيو',
  'يوليو',
  'أغسطس',
  'سبتمبر',
  'أكتوبر',
  'نوفمبر',
  'ديسمبر',
];

const ARABIC_MONTHS_HIJRI = [
  'محرّم',
  'صفر',
  'ربيع الأول',
  'ربيع الثاني',
  'جمادى الأولى',
  'جمادى الآخرة',
  'رجب',
  'شعبان',
  'رمضان',
  'شوّال',
  'ذو القعدة',
  'ذو الحجة',
];

export function toArabicDigits(num: number | string): string {
  const map = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
  return String(num).replace(/[0-9]/g, (d) => map[Number(d)]);
}

export function gregorianToHijri(year: number, month: number, day: number): { hy: number; hm: number; hd: number } {
  const jd = Math.floor(
    (11 * year + 3) / 400 +
      Math.floor((153 * (month + 12 - 1) + 2) / 5) +
      day +
      Math.floor(1461 * year / 4) -
      146096 / 2
  );
  const l1 = jd - 1948440 + 10632;
  const n1 = Math.floor((l1 - 1) / 10631);
  const l2 = l1 - 10631 * n1 + 354;
  const j1 =
    Math.floor((10985 - l2) / 5316) * Math.floor((50 * l2) / 17719) +
    Math.floor(l2 / 5670) * Math.floor((43 * l2) / 15238);
  const l3 = l2 - Math.floor((30 - j1) / 15) * Math.floor((17719 * j1) / 50) - Math.floor(j1 / 16) * Math.floor((15238 * j1) / 43) + 29;
  const hm = Math.floor((24 * l3) / 709);
  const hd = l3 - Math.floor((709 * hm) / 24);
  const hy = 30 * n1 + j1 - 30;
  return { hy, hm: Math.max(0, Math.min(11, hm - 1)), hd: Math.max(1, hd) };
}

export interface DayInfo {
  index: number;
  date: Date;
  dayName: string;
  gregorian: string;
  hijri: string;
  hijriShort: string;
}

export function getMonthDays(year: number, month: number): DayInfo[] {
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const result: DayInfo[] = [];
  for (let i = 1; i <= daysInMonth; i++) {
    const date = new Date(year, month, i);
    const dayName = ARABIC_DAYS[date.getDay()];
    const gregorian = `${toArabicDigits(i)} ${ARABIC_MONTHS_GREG[month]}`;
    const { hy, hm, hd } = gregorianToHijri(year, month, i);
    const hijri = `${toArabicDigits(hd)} ${ARABIC_MONTHS_HIJRI[hm]} ${toArabicDigits(hy)} هـ`;
    const hijriShort = `${toArabicDigits(hd)} ${ARABIC_MONTHS_HIJRI[hm]}`;
    result.push({ index: i, date, dayName, gregorian, hijri, hijriShort });
  }
  return result;
}

export function formatMonthLabel(year: number, month: number): string {
  return `${ARABIC_MONTHS_GREG[month]} ${toArabicDigits(year)}`;
}
