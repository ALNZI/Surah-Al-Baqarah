import { useCallback, useEffect, useState } from 'react';

export interface DayState {
  baqarah: boolean;
  istighfar: number;
}

export interface TrackerData {
  [day: number]: DayState;
}

const STORAGE_KEY = 'baqarah-istighfar-tracker';

function loadInitial(): TrackerData {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw) as TrackerData;
  } catch {
    // ignore
  }
  return {};
}

export function useTrackerData() {
  const [data, setData] = useState<TrackerData>(loadInitial);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch {
      // ignore
    }
  }, [data]);

  const getDay = useCallback(
    (day: number): DayState => data[day] ?? { baqarah: false, istighfar: 0 },
    [data],
  );

  const toggleBaqarah = useCallback((day: number) => {
    setData((prev) => ({
      ...prev,
      [day]: { ...(prev[day] ?? { baqarah: false, istighfar: 0 }), baqarah: !prev[day]?.baqarah },
    }));
  }, []);

  const incrementIstighfar = useCallback((day: number, by: number) => {
    setData((prev) => {
      const cur = prev[day] ?? { baqarah: false, istighfar: 0 };
      return {
        ...prev,
        [day]: { ...cur, istighfar: Math.max(0, cur.istighfar + by) },
      };
    });
  }, []);

  const reset = useCallback(() => {
    setData({});
  }, []);

  return { data, getDay, toggleBaqarah, incrementIstighfar, reset };
}
