import { useMemo, useState } from 'react';
import {
  BookOpen,
  Check,
  RotateCcw,
  Sparkles,
  TrendingUp,
  Calendar,
  HandHeart,
  Award,
  ChevronLeft,
  ChevronRight,
  X,
} from 'lucide-react';
import { getMonthDays, formatMonthLabel, toArabicDigits, type DayInfo } from '@/lib/dates';
import { useTrackerData } from '@/hooks/useTrackerData';

const ISTIGHFAR_TARGET = 100;

export default function Tracker() {
  const now = new Date();
  const [viewYear, setViewYear] = useState(now.getFullYear());
  const [viewMonth, setViewMonth] = useState(now.getMonth());
  const [confirmReset, setConfirmReset] = useState(false);
  const [justCompleted, setJustCompleted] = useState<number | null>(null);

  const { data, getDay, toggleBaqarah, incrementIstighfar, reset } = useTrackerData();

  const days = useMemo(() => getMonthDays(viewYear, viewMonth), [viewYear, viewMonth]);

  const todayKey = useMemo(() => {
    const t = new Date();
    return t.getFullYear() === viewYear && t.getMonth() === viewMonth ? t.getDate() : -1;
  }, [viewYear, viewMonth]);

  const stats = useMemo(() => {
    let baqarahCount = 0;
    let istighfarTotal = 0;
    let fullDays = 0;
    for (let i = 1; i <= days.length; i++) {
      const st = data[i];
      if (st?.baqarah) baqarahCount++;
      if (st?.istighfar) istighfarTotal += st.istighfar;
      if (st?.baqarah && (st.istighfar ?? 0) >= ISTIGHFAR_TARGET) fullDays++;
    }
    return {
      baqarahCount,
      istighfarTotal,
      fullDays,
      baqarahPct: Math.round((baqarahCount / days.length) * 100),
      istighfarPct: Math.min(100, Math.round((istighfarTotal / (days.length * ISTIGHFAR_TARGET)) * 100)),
      fullPct: Math.round((fullDays / days.length) * 100),
    };
  }, [data, days.length]);

  const handleToggle = (day: number) => {
    const wasDone = getDay(day).baqarah;
    toggleBaqarah(day);
    if (!wasDone) {
      setJustCompleted(day);
      setTimeout(() => setJustCompleted(null), 600);
    }
  };

  const goPrevMonth = () => {
    if (viewMonth === 0) {
      setViewMonth(11);
      setViewYear((y) => y - 1);
    } else {
      setViewMonth((m) => m - 1);
    }
  };

  const goNextMonth = () => {
    if (viewMonth === 11) {
      setViewMonth(0);
      setViewYear((y) => y + 1);
    } else {
      setViewMonth((m) => m + 1);
    }
  };

  const goToday = () => {
    const t = new Date();
    setViewYear(t.getFullYear());
    setViewMonth(t.getMonth());
  };

  const handleReset = () => {
    reset();
    setConfirmReset(false);
  };

  return (
    <div className="min-h-screen w-full">
      {/* Decorative top band */}
      <div className="relative overflow-hidden bg-gradient-to-l from-sage-700 via-sage-600 to-sage-700">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute -top-10 -right-10 h-48 w-48 rounded-full bg-gold-300 blur-3xl" />
          <div className="absolute top-20 left-10 h-40 w-40 rounded-full bg-sage-300 blur-3xl" />
        </div>
        <div className="relative mx-auto max-w-6xl px-4 py-10 sm:px-6 sm:py-14">
          <div className="flex flex-col items-center text-center">
            <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-white/15 backdrop-blur-sm ring-1 ring-white/20">
              <BookOpen className="h-8 w-8 text-gold-200" strokeWidth={1.5} />
            </div>
            <h1 className="font-quran text-3xl font-bold text-white sm:text-4xl">
              مُتابعة سورة البقرة والاستغفار
            </h1>
            <p className="mt-3 max-w-xl text-sm leading-relaxed text-sage-100 sm:text-base">
              جدولك اليومي لختم سورة البقرة والمواظبة على الاستغفار — احفظ تقدّمك يومًا بيوم
              ولا تفقد بياناتك أبدًا.
            </p>
            <div className="mt-5 inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-1.5 text-xs font-medium text-gold-100 ring-1 ring-white/15 backdrop-blur-sm">
              <Sparkles className="h-3.5 w-3.5" />
              <span>يُحفظ تلقائيًا في متصفحك</span>
            </div>
          </div>
        </div>
        {/* Wavy bottom */}
        <svg className="block w-full text-sage-50" viewBox="0 0 1440 60" preserveAspectRatio="none" style={{ height: 40 }}>
          <path
            fill="currentColor"
            d="M0,30 C240,60 480,0 720,20 C960,40 1200,10 1440,30 L1440,60 L0,60 Z"
          />
        </svg>
      </div>

      <main className="mx-auto -mt-2 max-w-6xl px-4 pb-20 sm:px-6">
        {/* Stats cards */}
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 sm:gap-4">
          <StatCard
            icon={<BookOpen className="h-5 w-5" />}
            label="أيام البقرة"
            value={`${toArabicDigits(stats.baqarahCount)} / ${toArabicDigits(days.length)}`}
            pct={stats.baqarahPct}
            color="sage"
          />
          <StatCard
            icon={<HandHeart className="h-5 w-5" />}
            label="مجمّع الاستغفار"
            value={toArabicDigits(stats.istighfarTotal)}
            pct={stats.istighfarPct}
            color="gold"
          />
          <StatCard
            icon={<Award className="h-5 w-5" />}
            label="أيام مكتملة"
            value={`${toArabicDigits(stats.fullDays)} / ${toArabicDigits(days.length)}`}
            pct={stats.fullPct}
            color="sage"
          />
          <StatCard
            icon={<TrendingUp className="h-5 w-5" />}
            label="نسبة الإنجاز"
            value={`${toArabicDigits(stats.fullPct)}٪`}
            pct={stats.fullPct}
            color="gold"
          />
        </div>

        {/* Month navigation + reset */}
        <div className="mt-6 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              onClick={goPrevMonth}
              className="flex h-10 w-10 items-center justify-center rounded-xl bg-white text-sage-700 shadow-sm ring-1 ring-sage-200 transition hover:bg-sage-50 hover:shadow active:scale-95"
              aria-label="الشهر السابق"
            >
              <ChevronRight className="h-5 w-5" />
            </button>
            <div className="flex min-w-[180px] flex-col items-center rounded-xl bg-white px-5 py-2 shadow-sm ring-1 ring-sage-200">
              <span className="text-sm font-bold text-sage-800">
                {formatMonthLabel(viewYear, viewMonth)}
              </span>
              <button onClick={goToday} className="text-[11px] text-gold-600 hover:text-gold-700">
                العودة لليوم
              </button>
            </div>
            <button
              onClick={goNextMonth}
              className="flex h-10 w-10 items-center justify-center rounded-xl bg-white text-sage-700 shadow-sm ring-1 ring-sage-200 transition hover:bg-sage-50 hover:shadow active:scale-95"
              aria-label="الشهر التالي"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>
          </div>

          <button
            onClick={() => setConfirmReset(true)}
            className="inline-flex items-center gap-2 rounded-xl bg-white px-4 py-2.5 text-sm font-medium text-red-600 shadow-sm ring-1 ring-red-200 transition hover:bg-red-50 active:scale-95"
          >
            <RotateCcw className="h-4 w-4" />
            إعادة الضبط
          </button>
        </div>

        {/* Table — desktop */}
        <div className="mt-5 hidden overflow-hidden rounded-2xl bg-white shadow-lg ring-1 ring-sage-200 md:block">
          <table className="w-full">
            <thead>
              <tr className="bg-gradient-to-l from-sage-700 to-sage-600 text-white">
                <th className="w-16 px-4 py-4 text-center text-sm font-bold">اليوم</th>
                <th className="px-4 py-4 text-center text-sm font-bold">التاريخ</th>
                <th className="px-4 py-4 text-center text-sm font-bold">سورة البقرة</th>
                <th className="px-4 py-4 text-center text-sm font-bold">الاستغفار</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-sage-100">
              {days.map((day) => (
                <DesktopRow
                  key={day.index}
                  day={day}
                  isToday={day.index === todayKey}
                  state={getDay(day.index)}
                  justCompleted={justCompleted === day.index}
                  onToggle={() => handleToggle(day.index)}
                  onInc={(by) => incrementIstighfar(day.index, by)}
                />
              ))}
            </tbody>
          </table>
        </div>

        {/* Cards — mobile */}
        <div className="mt-5 space-y-3 md:hidden">
          {days.map((day) => (
            <MobileCard
              key={day.index}
              day={day}
              isToday={day.index === todayKey}
              state={getDay(day.index)}
              justCompleted={justCompleted === day.index}
              onToggle={() => handleToggle(day.index)}
              onInc={(by) => incrementIstighfar(day.index, by)}
            />
          ))}
        </div>
      </main>

      <footer className="border-t border-sage-200 bg-white/60 py-6 text-center">
        <p className="font-quran text-sm text-sage-600">
          ﴿ وَاسْتَغْفِرِ اللَّهَ إِنَّ اللَّهَ كَانَ غَفُورًا رَحِيمًا ﴾
        </p>
      </footer>

      {/* Reset confirmation modal */}
      {confirmReset && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="absolute inset-0 bg-sage-900/40 backdrop-blur-sm animate-fadeIn"
            onClick={() => setConfirmReset(false)}
          />
          <div className="relative w-full max-w-sm animate-scaleIn rounded-2xl bg-white p-6 shadow-2xl ring-1 ring-sage-200">
            <button
              onClick={() => setConfirmReset(false)}
              className="absolute left-4 top-4 text-sage-400 transition hover:text-sage-600"
            >
              <X className="h-5 w-5" />
            </button>
            <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-red-50">
              <RotateCcw className="h-7 w-7 text-red-500" />
            </div>
            <h3 className="mb-2 text-center text-lg font-bold text-sage-800">إعادة الضبط</h3>
            <p className="mb-5 text-center text-sm leading-relaxed text-sage-500">
              سيتم مسح جميع بياناتك لهذا الشهر. لا يمكن التراجع عن هذا الإجراء.
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setConfirmReset(false)}
                className="flex-1 rounded-xl bg-sage-100 py-2.5 text-sm font-medium text-sage-700 transition hover:bg-sage-200 active:scale-95"
              >
                إلغاء
              </button>
              <button
                onClick={handleReset}
                className="flex-1 rounded-xl bg-red-500 py-2.5 text-sm font-medium text-white transition hover:bg-red-600 active:scale-95"
              >
                نعم، إعادة الضبط
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ---------- Stat Card ---------- */

function StatCard({
  icon,
  label,
  value,
  pct,
  color,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  pct: number;
  color: 'sage' | 'gold';
}) {
  const barFrom = color === 'sage' ? 'from-sage-500' : 'from-gold-400';
  const barTo = color === 'sage' ? 'to-sage-600' : 'to-gold-500';
  const iconBg = color === 'sage' ? 'bg-sage-100 text-sage-600' : 'bg-gold-100 text-gold-600';
  return (
    <div className="rounded-2xl bg-white p-3.5 shadow-sm ring-1 ring-sage-200 transition hover:shadow-md sm:p-4">
      <div className="flex items-center gap-2.5">
        <div className={`flex h-9 w-9 items-center justify-center rounded-lg ${iconBg}`}>{icon}</div>
        <div className="min-w-0">
          <p className="truncate text-[11px] font-medium text-sage-400 sm:text-xs">{label}</p>
          <p className="text-base font-bold text-sage-800 sm:text-lg">{value}</p>
        </div>
      </div>
      <div className="mt-2.5 h-1.5 w-full overflow-hidden rounded-full bg-sage-100">
        <div
          className={`h-full rounded-full bg-gradient-to-l ${barFrom} ${barTo} transition-all duration-500`}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}

/* ---------- Desktop Row ---------- */

function DesktopRow({
  day,
  isToday,
  state,
  justCompleted,
  onToggle,
  onInc,
}: {
  day: DayInfo;
  isToday: boolean;
  state: { baqarah: boolean; istighfar: number };
  justCompleted: boolean;
  onToggle: () => void;
  onInc: (by: number) => void;
}) {
  const done = state.baqarah;
  const istPct = Math.min(100, (state.istighfar / ISTIGHFAR_TARGET) * 100);
  const istDone = state.istighfar >= ISTIGHFAR_TARGET;

  return (
    <tr className={`group transition hover:bg-sage-50/60 ${isToday ? 'bg-gold-50/50' : ''}`}>
      {/* Day number */}
      <td className="px-4 py-3 text-center">
        <div
          className={`mx-auto flex h-9 w-9 items-center justify-center rounded-lg text-sm font-bold ${
            isToday
              ? 'bg-gold-400 text-white shadow-sm'
              : done
                ? 'bg-sage-100 text-sage-700'
                : 'bg-sage-50 text-sage-500'
          }`}
        >
          {toArabicDigits(day.index)}
        </div>
      </td>

      {/* Date */}
      <td className="px-4 py-3">
        <div className="flex items-center gap-2.5">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-sage-50 text-sage-600">
            <Calendar className="h-4 w-4" />
          </div>
          <div>
            <p className="text-sm font-medium text-sage-700">{day.dayName}</p>
            <p className="text-xs text-sage-400">{day.gregorian}</p>
            <p className="text-[11px] text-gold-500">{day.hijriShort}</p>
          </div>
        </div>
      </td>

      {/* Baqarah toggle */}
      <td className="px-4 py-3 text-center">
        <button
          onClick={onToggle}
          className={`relative inline-flex items-center gap-2 rounded-xl px-5 py-2.5 text-sm font-medium transition active:scale-95 ${
            done
              ? 'bg-sage-500 text-white shadow-md shadow-sage-500/30'
              : 'bg-sage-50 text-sage-600 ring-1 ring-sage-200 hover:bg-sage-100'
          }`}
        >
          {done ? (
            <>
              <Check className="h-4 w-4" />
              أتممتها
            </>
          ) : (
            'لم أتممها'
          )}
          {justCompleted && (
            <span className="absolute inset-0 rounded-xl bg-sage-400/40 animate-pulseRing" />
          )}
        </button>
      </td>

      {/* Istighfar counter */}
      <td className="px-4 py-3">
        <div className="flex items-center justify-center gap-2">
          <button
            onClick={() => onInc(-10)}
            className="flex h-8 w-8 items-center justify-center rounded-lg bg-sage-50 text-xs font-bold text-sage-500 ring-1 ring-sage-200 transition hover:bg-sage-100 active:scale-90"
          >
            −١٠
          </button>
          <button
            onClick={() => onInc(-1)}
            className="flex h-8 w-8 items-center justify-center rounded-lg bg-sage-50 text-sm font-bold text-sage-500 ring-1 ring-sage-200 transition hover:bg-sage-100 active:scale-90"
          >
            −
          </button>
          <div className="relative min-w-[72px] text-center">
            <span
              className={`block text-lg font-bold tabular-nums ${
                istDone ? 'text-gold-600' : 'text-sage-700'
              }`}
            >
              {toArabicDigits(state.istighfar)}
            </span>
            <span className="text-[10px] text-sage-300">/ {toArabicDigits(ISTIGHFAR_TARGET)}</span>
            <div className="mt-1 h-1 w-full overflow-hidden rounded-full bg-sage-100">
              <div
                className={`h-full rounded-full transition-all duration-300 ${
                  istDone ? 'bg-gold-400' : 'bg-sage-400'
                }`}
                style={{ width: `${istPct}%` }}
              />
            </div>
          </div>
          <button
            onClick={() => onInc(1)}
            className="flex h-8 w-8 items-center justify-center rounded-lg bg-sage-100 text-sm font-bold text-sage-600 transition hover:bg-sage-200 active:scale-90"
          >
            +
          </button>
          <button
            onClick={() => onInc(10)}
            className="flex h-8 w-8 items-center justify-center rounded-lg bg-sage-100 text-xs font-bold text-sage-600 transition hover:bg-sage-200 active:scale-90"
          >
            +١٠
          </button>
          <button
            onClick={() => onInc(ISTIGHFAR_TARGET - state.istighfar)}
            className="inline-flex items-center gap-1 rounded-lg bg-gold-100 px-2.5 py-2 text-xs font-medium text-gold-700 ring-1 ring-gold-200 transition hover:bg-gold-200 active:scale-95"
            title="إنجاز سريع"
          >
            <Check className="h-3.5 w-3.5" />
          </button>
        </div>
      </td>
    </tr>
  );
}

/* ---------- Mobile Card ---------- */

function MobileCard({
  day,
  isToday,
  state,
  justCompleted,
  onToggle,
  onInc,
}: {
  day: DayInfo;
  isToday: boolean;
  state: { baqarah: boolean; istighfar: number };
  justCompleted: boolean;
  onToggle: () => void;
  onInc: (by: number) => void;
}) {
  const done = state.baqarah;
  const istPct = Math.min(100, (state.istighfar / ISTIGHFAR_TARGET) * 100);
  const istDone = state.istighfar >= ISTIGHFAR_TARGET;

  return (
    <div
      className={`rounded-2xl bg-white p-4 shadow-sm ring-1 transition ${
        isToday ? 'ring-2 ring-gold-300' : 'ring-sage-200'
      }`}
    >
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div
            className={`flex h-10 w-10 items-center justify-center rounded-lg text-sm font-bold ${
              isToday ? 'bg-gold-400 text-white' : 'bg-sage-100 text-sage-700'
            }`}
          >
            {toArabicDigits(day.index)}
          </div>
          <div>
            <p className="text-sm font-bold text-sage-700">{day.dayName}</p>
            <p className="text-xs text-sage-400">{day.gregorian}</p>
            <p className="text-[11px] text-gold-500">{day.hijriShort}</p>
          </div>
        </div>
        {isToday && (
          <span className="rounded-full bg-gold-100 px-2.5 py-1 text-[10px] font-bold text-gold-700">
            اليوم
          </span>
        )}
      </div>

      {/* Baqarah */}
      <div className="mt-3.5">
        <p className="mb-1.5 flex items-center gap-1.5 text-xs font-medium text-sage-500">
          <BookOpen className="h-3.5 w-3.5" /> سورة البقرة
        </p>
        <button
          onClick={onToggle}
          className={`relative w-full rounded-xl py-2.5 text-sm font-medium transition active:scale-[0.98] ${
            done
              ? 'bg-sage-500 text-white shadow-sm'
              : 'bg-sage-50 text-sage-600 ring-1 ring-sage-200'
          }`}
        >
          {done ? (
            <span className="inline-flex items-center gap-1.5">
              <Check className="h-4 w-4" /> أتممتها
            </span>
          ) : (
            'لم أتممها'
          )}
          {justCompleted && (
            <span className="absolute inset-0 rounded-xl bg-sage-400/40 animate-pulseRing" />
          )}
        </button>
      </div>

      {/* Istighfar */}
      <div className="mt-3">
        <div className="mb-1.5 flex items-center justify-between">
          <p className="flex items-center gap-1.5 text-xs font-medium text-sage-500">
            <HandHeart className="h-3.5 w-3.5" /> الاستغفار
          </p>
          <span className={`text-sm font-bold tabular-nums ${istDone ? 'text-gold-600' : 'text-sage-700'}`}>
            {toArabicDigits(state.istighfar)} / {toArabicDigits(ISTIGHFAR_TARGET)}
          </span>
        </div>
        <div className="mb-2 h-1.5 w-full overflow-hidden rounded-full bg-sage-100">
          <div
            className={`h-full rounded-full transition-all duration-300 ${
              istDone ? 'bg-gold-400' : 'bg-sage-400'
            }`}
            style={{ width: `${istPct}%` }}
          />
        </div>
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => onInc(-10)}
            className="flex-1 rounded-lg bg-sage-50 py-2 text-xs font-bold text-sage-500 ring-1 ring-sage-200 active:scale-95"
          >
            −١٠
          </button>
          <button
            onClick={() => onInc(-1)}
            className="flex-1 rounded-lg bg-sage-50 py-2 text-sm font-bold text-sage-500 ring-1 ring-sage-200 active:scale-95"
          >
            −
          </button>
          <button
            onClick={() => onInc(1)}
            className="flex-1 rounded-lg bg-sage-100 py-2 text-sm font-bold text-sage-600 active:scale-95"
          >
            +
          </button>
          <button
            onClick={() => onInc(10)}
            className="flex-1 rounded-lg bg-sage-100 py-2 text-xs font-bold text-sage-600 active:scale-95"
          >
            +١٠
          </button>
          <button
            onClick={() => onInc(ISTIGHFAR_TARGET - state.istighfar)}
            className="flex-1 rounded-lg bg-gold-100 py-2 text-xs font-medium text-gold-700 ring-1 ring-gold-200 active:scale-95"
          >
            <span className="inline-flex items-center justify-center gap-1">
              <Check className="h-3.5 w-3.5" /> إنجاز
            </span>
          </button>
        </div>
      </div>
    </div>
  );
}
